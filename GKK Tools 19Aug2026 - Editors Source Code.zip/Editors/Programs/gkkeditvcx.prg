*-***********************************************************************************************
*-* Written by:  Gregory A. Green
*-*              980 Windmill Parkway
*-*              Evans, GA  30809
*-*              green.gregory@comcast.net
*-*
*-* Copyright �2006-2011 Gregory A. Green
*-*
*-***********************************************************************************************
*-* Main entry point for application
*-*
FUNCTION GKKEditVCX
LPARAMETERS tcFileNm, tcClassNm, tlChkOut, tnProjRec, tcProjNm, tcMethod, tnLineNo
LOCAL lcSystemApp, loEditor, loRange
IF PEMSTATUS(_SCREEN, "GKKTools", 5)
	IF ISNULL(_SCREEN.GKKTools)
		_SCREEN.GKKTools = CREATEOBJECT("Empty")
	ENDIF
ELSE
	_SCREEN.AddProperty("GKKTools")
	_SCREEN.GKKTools = CREATEOBJECT("Empty")
ENDIF
IF !PEMSTATUS(_SCREEN.GKKTools, "LastDirectory", 5)
	ADDPROPERTY(_SCREEN.GKKTools, "LastDirectory", ADDBS(SYS(5) + SYS(2003)))
ENDIF
IF VARTYPE(tcFileNm)!="C" .OR. EMPTY(tcFileNm) .OR. !FILE(tcFileNm)
	tcFileNm = .NULL.
ENDIF
DO CASE
	CASE PCOUNT() = 1
		tcClassNm = .NULL.
		tlChkOut  = .T.
		tnProjRec = -1
		tcProjNm  = .NULL.
		tcMethod  = .NULL.
		tnLineNo  = 0

	CASE PCOUNT() = 2
		tlChkOut  = .T.
		tnProjRec = -1
		tcProjNm  = .NULL.
		tcMethod  = .NULL.
		tnLineNo  = 0

	CASE PCOUNT() = 3
		tnProjRec = -1
		tcProjNm  = .NULL.
		tcMethod  = .NULL.
		tnLineNo  = 0

	CASE PCOUNT() = 4
		tcProjNm = .NULL.
		tcMethod = .NULL.
		tnLineNo = 0

	CASE PCOUNT() = 5
		tcMethod  = .NULL.
		tnLineNo  = 0

	CASE PCOUNT() = 6
		tnLineNo  = 0

	CASE PCOUNT() = 7

	OTHERWISE
		tcFileNm  = .NULL.
		tcClassNm = .NULL.
		tlChkOut  = .T.
		tnProjRec = -1
		tcProjNm  = .NULL.
		tcMethod  = .NULL.
		tnLineNo  = 0
ENDCASE
IF !('GKKDeclareAPI' $ SET( 'Procedure' ))
	SET PROCEDURE TO GKKDeclareAPI ADDITIVE
ENDIF
lcSystemApp = GKKGetSystemAPP()
IF !EMPTY(lcSystemApp)
	DO (lcSystemApp)
	IF ISNULL(tcMethod)
		DO FORM GKKEditVcx WITH tcFileNm, tcClassNm, tlChkOut, tnProjRec, tcProjNm
	ELSE
		DO FORM GKKEditVcx WITH tcFileNm, tcClassNm, tlChkOut, tnProjRec, tcProjNm NAME loEditor
		SET DATASESSION TO loEditor.DataSessionId
		SELECT c_editbuffer
		LOCATE FOR ALLTRIM(LOWER(fullname)) == tcMethod
		IF FOUND()
			loEditor.DisplayMethod(ALLTRIM(c_editbuffer.wbs), .F.)
			WITH loEditor.CodeMaxTabs.CodeMax(loEditor.CodeMaxTabs.CurrentTab).oleCodeMax
				loRange = .GetSel(.F.)
				loRange.StartLineNo = tnLineNo
				loRange.StartColNo  = 0
				loRange.EndLineNo   = tnLineNo
				loRange.EndColNo    = 0
				.SetSel(loRange, .T.)
				.SelChange()
				.SetFocus()
			ENDWITH
		ENDIF
	ENDIF
ENDIF
ENDFUNC