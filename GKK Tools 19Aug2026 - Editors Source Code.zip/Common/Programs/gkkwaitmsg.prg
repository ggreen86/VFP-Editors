*-************************************************************************************************
*-* Copyright �2026 Gregory A. Green
*-*
*-* THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. ALL
*-* IMPLIED WARRANTIES OF FITNESS FOR ANY PARTICULAR PURPOSE ARE HEREBY DISCLAIMED.
*-*
*-************************************************************************************************
*-*
*-*  Routine for displaying a wait message
*-*
FUNCTION GKKWaitMsg
LPARAMETERS tcMessage
DO FORM GKKDisplayMsg WITH 0, tcMessage NAME loForm
INKEY(0.001, 'H')
RETURN loForm
ENDFUNC