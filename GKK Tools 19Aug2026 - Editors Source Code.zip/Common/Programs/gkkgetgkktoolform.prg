*-***********************************************************************************************
*-* Copyright �2005-2016 Gregory A. Green
*-*
*-* THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY. ALL
*-* IMPLIED WARRANTIES OF FITNESS FOR ANY PARTICULAR PURPOSE ARE HEREBY DISCLAIMED.
*-*
*-***********************************************************************************************
*-* Gets the specified GKK Tool window (thisform) reference
*-*
FUNCTION GKKGetGKKToolForm
LPARAMETERS tcGKKToolName, tcFileName
LOCAL llNotFound, lnForm
IF PCOUNT() = 1
	tcFileName = .NULL.
ENDIF
llNotFound = .T.
FOR lnForm=1 TO _SCREEN.FormCount
	IF PEMSTATUS(_SCREEN.Forms(lnForm), "FormName", 5) .AND. _SCREEN.Forms(lnForm).FormName = tcGKKToolName
		IF ISNULL(tcFileName)
			llNotFound = .F.
			EXIT
		ELSE
			IF PEMSTATUS(_SCREEN.Forms(lnForm), "FileName", 5) .AND. UPPER(_SCREEN.Forms(lnForm).FileName) == UPPER(tcFileName)
				llNotFound = .F.
				EXIT
			ENDIF
		ENDIF
	ENDIF
ENDFOR
IF llNotFound
	RETURN 0
ELSE
	RETURN lnForm
ENDIF
ENDFUNC