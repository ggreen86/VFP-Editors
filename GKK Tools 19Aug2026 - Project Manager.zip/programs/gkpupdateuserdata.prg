*-***********************************************************************************************
*-* Written by:  Gregory A. Green
*-*              980 Windmill Parkway
*-*              Evans, GA  30809
*-*              (706) 651-1640
*-*
*-***********************************************************************************************
*-*  Routine for adding data to the user memo field value
*-*
FUNCTION GKPUpdateUserData
LPARAMETERS tcName, tcDataValue, tcUserData
LOCAL lnNum, lnNdx
LOCAL ARRAY lcMemo[1]
tcName = tcName + " ="
IF ATC(tcName, tcUserData) > 0
	lnNum = ALINES(lcMemo, tcUserData, .T.)
	tcUserData = ""
	FOR lnNdx=1 TO lnNum
		IF !EMPTY(lcMemo[lnNdx])
			IF lcMemo[lnNdx] = tcName
				tcUserData = tcUserData + tcName + " " + tcDataValue + CHR(13) + CHR(10)
			ELSE
				tcUserData = tcUserData + lcMemo[lnNdx] + CHR(13) + CHR(10)
			ENDIF
		ENDIF
	ENDFOR
ELSE
	IF !EMPTY(tcUserData) .AND. RIGHT(tcUserData, 2) != CHR(13) + CHR(10)
		tcUserData = tcUserData + CHR(13) + CHR(10)
	ENDIF
	tcUserData = tcUserData + tcName + " " + tcDataValue + CHR(13) + CHR(10)
ENDIF
RETURN tcUserData
ENDFUNC