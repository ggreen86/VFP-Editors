FUNCTION GKKProjectDock
LPARAMETERS tcFileName
LOCAL lcSystemApp
IF !('GKPDeclareAPI' $ SET( 'Procedure' ))
	SET PROCEDURE TO GKKDeclareAPI ADDITIVE
ENDIF
IF PEMSTATUS(_SCREEN, "GKKTools", 5)
	IF ISNULL(_SCREEN.GKKTools)
		_SCREEN.GKKTools = CREATEOBJECT("Empty")
	ENDIF
ELSE
	_SCREEN.AddProperty("GKKTools")
	_SCREEN.GKKTools = CREATEOBJECT("Empty")
ENDIF
IF !PEMSTATUS(_SCREEN.GKKTools, "LastDirectory", 5)
	ADDPROPERTY(_SCREEN.GKKTools, "LastDirectory", ADDBS(SYS(5) + SYS(2003)))
ENDIF
SYS(2333, 0)
lcSystemApp = GKKGetSystemAPP()
IF !EMPTY(lcSystemApp)
	DO (lcSystemApp)
	IF VARTYPE(tcFileName)!="C" .OR. EMPTY(tcFileName)
		DO FORM GKPProjectDock
	ELSE
		DO FORM GKPProjectDock WITH tcFileName
	ENDIF
ENDIF
ENDFUNC